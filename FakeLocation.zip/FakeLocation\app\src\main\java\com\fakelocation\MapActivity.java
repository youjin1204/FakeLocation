package com.fakelocation;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.fakelocation.databinding.ActivityMapBinding;
import androidx.room.Room;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener {
    
    private ActivityMapBinding binding;
    private GoogleMap mMap;
    private double selectedLat = 39.9042;
    private double selectedLng = 116.4074; // 默认北京
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "fake_location_db")
                .allowMainThreadQueries()
                .build();
        
        SupportMapFragment mapFragment = (SupportMapFragment) 
            getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        
        updateCoordinatesDisplay();
        
        binding.btnCancel.setOnClickListener(v -> finish());
        binding.btnSave.setOnClickListener(v -> saveLocation(false));
        binding.btnUse.setOnClickListener(v -> saveLocation(true));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapClickListener(this);
        
        // 移动到默认位置北京
        LatLng defaultLocation = new LatLng(selectedLat, selectedLng);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 10f));
        addMarker(selectedLat, selectedLng);
    }

    @Override
    public void onMapClick(LatLng latLng) {
        selectedLat = latLng.latitude;
        selectedLng = latLng.longitude;
        addMarker(selectedLat, selectedLng);
        updateCoordinatesDisplay();
    }

    private void addMarker(double lat, double lng) {
        if (mMap != null) {
            mMap.clear();
            mMap.addMarker(new MarkerOptions().position(new LatLng(lat, lng)));
        }
    }

    private void updateCoordinatesDisplay() {
        binding.tvLatitude.setText(String.format("%.6f", selectedLat));
        binding.tvLongitude.setText(String.format("%.6f", selectedLng));
    }

    private void saveLocation(boolean andUse) {
        String name = binding.etLocationName.getText() != null 
            ? binding.etLocationName.getText().toString().trim() 
            : "";
        
        if (TextUtils.isEmpty(name)) {
            name = String.format("位置 %.6f, %.6f", selectedLat, selectedLng);
        }
        
        SavedLocation location = new SavedLocation(name, selectedLat, selectedLng);
        new Thread(() -> {
            db.locationDao().insert(location);
            runOnUiThread(() -> {
                Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                if (andUse) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("lat", selectedLat);
                    resultIntent.putExtra("lng", selectedLng);
                    resultIntent.putExtra("name", name);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            });
        }).start();
        
        if (!andUse) {
            finish();
        }
    }
}
