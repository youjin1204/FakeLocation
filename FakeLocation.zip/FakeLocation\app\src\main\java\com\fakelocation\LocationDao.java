package com.fakelocation;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LocationDao {
    
    @Query("SELECT * FROM saved_locations ORDER BY createdAt DESC")
    LiveData<List<SavedLocation>> getAllLocations();
    
    @Query("SELECT * FROM saved_locations ORDER BY createdAt DESC")
    List<SavedLocation> getAllLocationsSync();
    
    @Insert
    void insert(SavedLocation location);
    
    @Delete
    void delete(SavedLocation location);
    
    @Query("DELETE FROM saved_locations")
    void deleteAll();
}
