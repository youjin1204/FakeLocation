# 虚拟定位 - FakeLocation

安卓虚拟定位应用，可以模拟GPS位置，支持在地图上任意选择位置，保存常用地点。

## 功能特性

- ✅ 在Google地图上任意选择位置
- ✅ 保存常用位置，方便快速切换
- ✅ 后台持续模拟位置
- ✅ 支持Android 6.0+ 
- ✅ 简洁Material Design UI

## 使用方法

### 1. 开启开发者选项
- 打开手机 **设置 → 关于手机**
- 连续点击 **版本号** 7次，开启开发者选项

### 2. 设置允许模拟位置
- 进入 **设置 → 开发者选项**
- 找到 **选择模拟位置信息应用** (不同手机可能名称略有不同)
- 选择 **虚拟定位** 这个应用

### 3. 使用应用
1. 打开应用，点击 **在地图上选择**
2. 在地图上点击你想要模拟的位置
3. 可以给位置命名保存，直接点击使用
4. 应用会开始模拟位置，所有获取位置信息的App都会看到你设置的位置

## 项目结构

```
FakeLocation/
├── app/
│   └── src/main/
│       ├── java/com/fakelocation/
│       │   ├── MainActivity.java      # 主界面
│       │   ├── MapActivity.java       # 地图选择
│       │   ├── FakeLocationService.java # 后台定位服务
│       │   ├── SavedLocation.java     # 数据实体
│       │   ├── LocationDao.java       # Room DAO
│       │   ├── AppDatabase.java       # Room数据库
│       │   └── SavedLocationAdapter.java # 列表适配器
│       ├── res/
│       │   ├── layout/                # 布局文件
│       │   ├── values/                # 颜色、字符串、主题
│       │   ├── drawable/              # 图标资源
│       │   └── xml/                   # 配置文件
│       └── AndroidManifest.xml
├── build.gradle
└── settings.gradle
```

## 编译安装

1. 使用Android Studio打开项目
2. 确保已安装Android SDK API 34
3. 连接手机，点击运行即可安装

## 技术栈

- Java
- AndroidX Room 数据库
- Google Maps Android SDK
- Material Design
- ViewBinding

## 注意事项

- 需要Google Play服务支持地图显示
- 某些定位类应用可能检测到模拟位置，使用效果取决于目标应用
- 本应用仅供开发测试使用，请遵守当地法律法规

## License

MIT License
