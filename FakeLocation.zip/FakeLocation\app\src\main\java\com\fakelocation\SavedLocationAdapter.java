package com.fakelocation;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.fakelocation.databinding.ItemSavedLocationBinding;
import java.util.ArrayList;
import java.util.List;

public class SavedLocationAdapter extends RecyclerView.Adapter<SavedLocationAdapter.ViewHolder> {
    
    private List<SavedLocation> locations = new ArrayList<>();
    private final OnLocationClickListener listener;

    public interface OnLocationClickListener {
        void onUseClick(SavedLocation location);
        void onDeleteClick(SavedLocation location);
    }

    public SavedLocationAdapter(OnLocationClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemSavedLocationBinding binding = ItemSavedLocationBinding.inflate(
            LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SavedLocation location = locations.get(position);
        holder.binding.tvName.setText(location.getName());
        String coords = String.format("%.6f, %.6f", location.getLatitude(), location.getLongitude());
        holder.binding.tvCoords.setText(coords);
        
        holder.binding.btnUse.setOnClickListener(v -> {
            if (listener != null) {
                listener.onUseClick(location);
            }
        });
        
        holder.binding.btnDelete.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(location);
            }
        });
    }

    @Override
    public int getItemCount() {
        return locations.size();
    }

    public void setLocations(List<SavedLocation> locations) {
        this.locations = locations;
        notifyDataSetChanged();
    }

    public void removeLocation(SavedLocation location) {
        int position = locations.indexOf(location);
        if (position >= 0) {
            locations.remove(position);
            notifyItemRemoved(position);
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemSavedLocationBinding binding;

        ViewHolder(ItemSavedLocationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
