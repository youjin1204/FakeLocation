package com.fakelocation;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.room.Room;
import com.fakelocation.databinding.ActivityMainBinding;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SavedLocationAdapter.OnLocationClickListener {
    
    private static final int REQUEST_PERMISSIONS = 100;
    private static final int REQUEST_MAP = 101;
    
    private ActivityMainBinding binding;
    private SavedLocationAdapter adapter;
    private AppDatabase db;
    private Double currentLat = null;
    private Double currentLng = null;
    private String currentName = null;
    private boolean isFakeRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "fake_location_db")
                .build();
        
        setupViews();
        checkPermissions();
        observeService();
        loadSavedLocations();
        
        // 显示使用说明
        showInstructions();
    }

    private void setupViews() {
        binding.btnSelectMap.setOnClickListener(v -> {
            openMap();
        });
        
        binding.btnToggleFake.setOnClickListener(v -> {
            if (isFakeRunning) {
                stopFakeLocation();
            } else {
                startFakeLocation();
            }
        });
        
        binding.rvSavedLocations.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SavedLocationAdapter(this);
        binding.rvSavedLocations.setAdapter(adapter);
    }

    private void checkPermissions() {
        List<String> permissionsNeeded = new java.util.ArrayList<>();
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
            != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) 
            != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        
        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, 
                permissionsNeeded.toArray(new String[0]), REQUEST_PERMISSIONS);
        }
    }

    private void showInstructions() {
        new AlertDialog.Builder(this)
            .setTitle("使用说明")
            .setMessage(R.string.mock_location_notice + "\n\n" +
                "1. 打开手机设置 -> 开发者选项\n" +
                "2. 找到「允许模拟位置信息」或「选择模拟位置信息应用」\n" +
                "3. 选择本应用「虚拟定位」\n" +
                "4. 在地图上选择要模拟的位置，点击开始即可")
            .setPositiveButton("我知道了", null)
            .show();
    }

    private void openMap() {
        Intent intent = new Intent(this, MapActivity.class);
        startActivityForResult(intent, REQUEST_MAP);
    }

    private void startFakeLocation() {
        if (currentLat == null || currentLng == null) {
            Toast.makeText(this, "请先选择位置", Toast.LENGTH_SHORT).show();
            return;
        }
        
        Intent intent = new Intent(this, FakeLocationService.class);
        intent.setAction(FakeLocationService.ACTION_START);
        intent.putExtra(FakeLocationService.EXTRA_LAT, currentLat);
        intent.putExtra(FakeLocationService.EXTRA_LNG, currentLng);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        
        isFakeRunning = true;
        updateToggleButton();
        Toast.makeText(this, getString(R.string.fake_location_running), Toast.LENGTH_SHORT).show();
    }

    private void stopFakeLocation() {
        Intent intent = new Intent(this, FakeLocationService.class);
        intent.setAction(FakeLocationService.ACTION_STOP);
        startService(intent);
        stopService(intent);
        isFakeRunning = false;
        updateToggleButton();
        Toast.makeText(this, getString(R.string.fake_location_stopped), Toast.LENGTH_SHORT).show();
    }

    private void updateToggleButton() {
        if (isFakeRunning) {
            binding.btnToggleFake.setText(R.string.stop_fake);
        } else {
            binding.btnToggleFake.setText(R.string.start_fake);
        }
    }

    private void updateCurrentLocationDisplay() {
        if (currentName != null && currentLat != null && currentLng != null) {
            binding.tvCurrentLocation.setText(currentName);
            binding.tvCoordinates.setText(String.format("%.6f, %.6f", currentLat, currentLng));
            binding.tvCoordinates.setVisibility(android.view.View.VISIBLE);
            binding.btnToggleFake.setEnabled(true);
        } else {
            binding.tvCurrentLocation.setText(R.string.no_location_selected);
            binding.tvCoordinates.setVisibility(android.view.View.GONE);
            binding.btnToggleFake.setEnabled(false);
        }
    }

    private void loadSavedLocations() {
        LiveData<List<SavedLocation>> locations = db.locationDao().getAllLocations();
        locations.observe(this, savedLocations -> {
            adapter.setLocations(savedLocations);
        });
    }

    private void observeService() {
        FakeLocationService.getServiceRunning().observe(this, running -> {
            isFakeRunning = running != null && running;
            updateToggleButton();
        });
        
        FakeLocationService.getFakeLocation().observe(this, location -> {
            // 可以在这里更新UI显示当前位置
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, 
        @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (!allGranted) {
                Toast.makeText(this, R.string.permission_required, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MAP && resultCode == RESULT_OK && data != null) {
            currentLat = data.getDoubleExtra("lat", 0);
            currentLng = data.getDoubleExtra("lng", 0);
            currentName = data.getStringExtra("name");
            updateCurrentLocationDisplay();
            startFakeLocation();
        }
    }

    @Override
    public void onUseClick(SavedLocation location) {
        currentLat = location.getLatitude();
        currentLng = location.getLongitude();
        currentName = location.getName();
        updateCurrentLocationDisplay();
        startFakeLocation();
    }

    @Override
    public void onDeleteClick(SavedLocation location) {
        new AlertDialog.Builder(this)
            .setTitle(R.string.delete)
            .setMessage("确定要删除这个位置吗？")
            .setPositiveButton(R.string.confirm, (dialog, which) -> {
                new Thread(() -> {
                    db.locationDao().delete(location);
                }).start();
                adapter.removeLocation(location);
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!isFakeRunning) {
            stopService(new Intent(this, FakeLocationService.class));
        }
    }
}
