package com.fakelocation;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.room.Room;
import android.app.Service;

import com.google.android.gms.location.LocationRequest;

public class FakeLocationService extends Service {
    
    public static final String CHANNEL_ID = "fake_location_channel";
    public static final String ACTION_START = "com.fakelocation.START";
    public static final String ACTION_STOP = "com.fakelocation.STOP";
    public static final String EXTRA_LAT = "extra_lat";
    public static final String EXTRA_LNG = "extra_lng";
    
    private static boolean isRunning = false;
    private LocationManager locationManager;
    private double currentLat = 0;
    private double currentLng = 0;
    
    private static MutableLiveData<Location> fakeLocation = new MutableLiveData<>();
    private static MutableLiveData<Boolean> serviceRunning = new MutableLiveData<>();

    @Override
    public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        serviceRunning.setValue(false);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopFakeLocation();
            stopSelf();
            return START_NOT_STICKY;
        }
        
        if (intent != null) {
            currentLat = intent.getDoubleExtra(EXTRA_LAT, 0);
            currentLng = intent.getDoubleExtra(EXTRA_LNG, 0);
        }
        
        startForeground(1, buildNotification());
        startFakeLocation(currentLat, currentLng);
        serviceRunning.setValue(true);
        isRunning = true;
        return START_STICKY;
    }

    private void startFakeLocation(double lat, double lng) {
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            
            // 清除所有位置提供者，设置测试提供者
            for (String provider : locationManager.getAllProviders()) {
                locationManager.removeTestProvider(provider);
            }
            
            // 设置GPS提供者
            if (locationManager.getProvider(LocationManager.GPS_PROVIDER) != null) {
                locationManager.addTestProvider(LocationManager.GPS_PROVIDER,
                    false, false, false, false, true, true, true,
                    0, android.location.Criteria.ACCURACY_FINE);
                locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);
            }
            
            // 设置网络提供者
            if (locationManager.getProvider(LocationManager.NETWORK_PROVIDER) != null) {
                locationManager.addTestProvider(LocationManager.NETWORK_PROVIDER,
                    false, false, false, false, true, true, true,
                    0, android.location.Criteria.ACCURACY_COARSE);
                locationManager.setTestProviderEnabled(LocationManager.NETWORK_PROVIDER, true);
            }
            
            // 发送第一次位置更新
            updateLocation(lat, lng);
            
            // 持续更新位置（每隔1秒）
            new Thread(() -> {
                while (isRunning) {
                    updateLocation(lat, lng);
                    SystemClock.sleep(1000);
                }
            }).start();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateLocation(double lat, double lng) {
        if (locationManager == null) return;
        
        Location location = new Location(LocationManager.GPS_PROVIDER);
        location.setLatitude(lat);
        location.setLongitude(lng);
        location.setAccuracy(10f);
        location.setTime(System.currentTimeMillis());
        location.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
        location.setAltitude(0);
        location.setBearing(0);
        location.setSpeed(0);
        
        try {
            locationManager.setTestProviderLocation(LocationManager.GPS_PROVIDER, location);
        } catch (Exception e) {
            // Ignore
        }
        
        try {
            Location netLocation = new Location(LocationManager.NETWORK_PROVIDER);
            netLocation.setLatitude(lat);
            netLocation.setLongitude(lng);
            netLocation.setAccuracy(50f);
            netLocation.setTime(System.currentTimeMillis());
            netLocation.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
            locationManager.setTestProviderLocation(LocationManager.NETWORK_PROVIDER, netLocation);
        } catch (Exception e) {
            // Ignore
        }
        
        fakeLocation.postValue(location);
    }

    private void stopFakeLocation() {
        try {
            for (String provider : locationManager.getAllProviders()) {
                try {
                    locationManager.removeTestProvider(provider);
                } catch (Exception e) {
                    // Ignore
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        isRunning = false;
        serviceRunning.setValue(false);
    }

    private Notification buildNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_content))
            .setSmallIcon(R.drawable.ic_location)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true);
        
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public static boolean isRunning() {
        return isRunning;
    }

    public static LiveData<Boolean> getServiceRunning() {
        return serviceRunning;
    }

    public static LiveData<Location> getFakeLocation() {
        return fakeLocation;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopFakeLocation();
    }
}
